import boto3
import json
import os

dynamo = boto3.resource("dynamodb").Table(os.environ['VC_DB'])

print('Loading function')

def lambda_handler(event, context):
    dbresponse = dynamo.update_item(
        Key = {
                'VisitorCounter': 'Resume'
        },
        UpdateExpression='SET website_counter = website_counter + :one',
        ExpressionAttributeValues={
            ':one': 1
        },
        ReturnValues="UPDATED_NEW"
    )   
        
    responseBody = json.dumps({"count": int(dbresponse["Attributes"]["website_counter"])})   
    apiResponse = {
        "isBase64Encoded": False,
        "statusCode": 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
        },
        "body": responseBody
    }

    return apiResponse